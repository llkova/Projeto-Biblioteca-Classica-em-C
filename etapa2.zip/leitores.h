// ============================================================================
// Arquivo: leitores.h | MODULO 1: FICHARIO DE LEITORES
// Autor: Lucas Bozek - RGM
// ============================================================================
#ifndef LEITORES_H
#define LEITORES_H

#include <stdio.h>
#include <string.h>

struct Leitor {
    int idLeitor;
    char nome[50];
    char telefone[20];
    int livrosEmprestados; // quantos livros o leitor tem em maos agora
    float multaPendente;   // multa de atraso ainda nao quitada (R$)
    int ativo;             // 1 = Ativo, 0 = Removido
};

struct Leitor listaLeitores[50];
int totalLeitores = 0;

// Grava (ou regrava) todo o vetor no arquivo leitores.csv
// Autor: Lucas Bozek - RGM
void salvarLeitoresCSV() {
    int i;
    FILE *arq = fopen("leitores.csv", "w"); // modo "w" zera o arquivo e regrava tudo
    if (arq == NULL) {
        printf("[ERRO] Nao foi possivel gravar leitores.csv!\n");
        return;
    }
    for (i = 0; i < totalLeitores; i++) {
        fprintf(arq, "%d;%s;%s;%d;%.2f;%d\n",
                listaLeitores[i].idLeitor,
                listaLeitores[i].nome,
                listaLeitores[i].telefone,
                listaLeitores[i].livrosEmprestados,
                listaLeitores[i].multaPendente,
                listaLeitores[i].ativo);
    }
    fclose(arq);
}

// Carrega os leitores do arquivo leitores.csv ao abrir o programa
// Autor: Lucas Bozek - RGM
void carregarLeitoresCSV() {
    FILE *arq = fopen("leitores.csv", "r");
    if (arq == NULL) return; // se o arquivo ainda nao existe, comeca com 0 registros

    totalLeitores = 0;
    while (totalLeitores < 50 &&
           fscanf(arq, "%d;%49[^;];%19[^;];%d;%f;%d\n",
                  &listaLeitores[totalLeitores].idLeitor,
                  listaLeitores[totalLeitores].nome,
                  listaLeitores[totalLeitores].telefone,
                  &listaLeitores[totalLeitores].livrosEmprestados,
                  &listaLeitores[totalLeitores].multaPendente,
                  &listaLeitores[totalLeitores].ativo) == 6) {
        totalLeitores++;
    }
    fclose(arq);
}

// Procura um leitor ATIVO pelo ID. Retorna a posicao no vetor ou -1 se nao achar.
// Autor: Lucas Bozek - RGM
int buscarIndiceLeitor(int id) {
    int i;
    for (i = 0; i < totalLeitores; i++) {
        if (listaLeitores[i].idLeitor == id && listaLeitores[i].ativo == 1) {
            return i;
        }
    }
    return -1;
}

// Autor: Lucas Bozek - RGM
void cadastrarLeitor() {
    if (totalLeitores >= 50) {
        printf("\n[ERRO] Fichario cheio (maximo de 50 leitores)!\n");
        return;
    }

    // ID automatico: como o leitor removido continua no vetor (ativo = 0), o ID nunca se repete
    listaLeitores[totalLeitores].idLeitor = totalLeitores + 1;

    printf("\n--- CADASTRAR LEITOR (ID %d) ---\n", listaLeitores[totalLeitores].idLeitor);
    printf("Nome: ");
    scanf(" %49[^\n]", listaLeitores[totalLeitores].nome);
    printf("Telefone: ");
    scanf(" %19[^\n]", listaLeitores[totalLeitores].telefone);
    listaLeitores[totalLeitores].livrosEmprestados = 0;
    listaLeitores[totalLeitores].multaPendente = 0.0;
    listaLeitores[totalLeitores].ativo = 1;

    totalLeitores++;
    salvarLeitoresCSV();
    printf("\nLeitor cadastrado com sucesso e salvo em 'leitores.csv'!\n");
}

// Autor: Lucas Bozek - RGM
void listarLeitores() {
    int i, encontrou = 0;

    printf("\n--- FICHARIO DE LEITORES ---\n");
    printf("%-4s %-24s %-16s %-7s %-8s\n", "ID", "Nome", "Telefone", "Livros", "Multa");
    for (i = 0; i < totalLeitores; i++) {
        if (listaLeitores[i].ativo == 1) {
            printf("%-4d %-24s %-16s %-7d R$%-6.2f\n",
                   listaLeitores[i].idLeitor, listaLeitores[i].nome,
                   listaLeitores[i].telefone, listaLeitores[i].livrosEmprestados,
                   listaLeitores[i].multaPendente);
            encontrou = 1;
        }
    }
    if (encontrou == 0) {
        printf("Nenhum leitor cadastrado.\n");
    }
}

// Busca textual: procura um pedaco do nome com strstr
// Autor: Lucas Bozek - RGM
void buscarLeitorPorNome() {
    char termo[50];
    int i, encontrou = 0;

    printf("\nDigite parte do nome do leitor: ");
    scanf(" %49[^\n]", termo);

    printf("\n--- RESULTADO DA BUSCA ---\n");
    for (i = 0; i < totalLeitores; i++) {
        if (listaLeitores[i].ativo == 1 && strstr(listaLeitores[i].nome, termo) != NULL) {
            printf("ID %d | %s | %s | %d livro(s) | multa R$ %.2f\n",
                   listaLeitores[i].idLeitor, listaLeitores[i].nome,
                   listaLeitores[i].telefone, listaLeitores[i].livrosEmprestados,
                   listaLeitores[i].multaPendente);
            encontrou = 1;
        }
    }
    if (encontrou == 0) {
        printf("Nenhum leitor encontrado com esse nome.\n");
    }
}

// Edita um campo na memoria e regrava o CSV inteiro
// Autor: Lucas Bozek - RGM
void editarLeitor() {
    int id, i, campo;

    printf("\nDigite o ID do leitor que deseja editar: ");
    scanf("%d", &id);
    i = buscarIndiceLeitor(id);

    if (i == -1) {
        printf("\n[ERRO] Leitor com ID %d nao encontrado.\n", id);
        return;
    }

    printf("\nEditando: %s | Telefone: %s | Multa pendente: R$ %.2f\n",
           listaLeitores[i].nome, listaLeitores[i].telefone, listaLeitores[i].multaPendente);
    printf("Qual campo deseja alterar?\n");
    printf("1. Nome\n");
    printf("2. Telefone\n");
    printf("3. Multa pendente (digite 0 para quitar)\n");
    printf("0. Cancelar\n");
    printf("Escolha: ");
    scanf("%d", &campo);

    switch (campo) {
        case 1:
            printf("Novo nome: ");
            scanf(" %49[^\n]", listaLeitores[i].nome);
            salvarLeitoresCSV();
            printf("\nNome atualizado!\n");
            break;
        case 2:
            printf("Novo telefone: ");
            scanf(" %19[^\n]", listaLeitores[i].telefone);
            salvarLeitoresCSV();
            printf("\nTelefone atualizado!\n");
            break;
        case 3:
            printf("Novo valor da multa (R$): ");
            scanf("%f", &listaLeitores[i].multaPendente);
            salvarLeitoresCSV();
            printf("\nMulta atualizada!\n");
            break;
        case 0:
            printf("\nEdicao cancelada.\n");
            break;
        default:
            printf("\n[ERRO] Opcao invalida!\n");
    }
}

// Remocao logica (ativo = 0). Regra de negocio: nao remove leitor com livro em maos.
// Autor: Lucas Bozek - RGM
void removerLeitor() {
    int id, i;

    printf("\nDigite o ID do leitor que deseja remover: ");
    scanf("%d", &id);
    i = buscarIndiceLeitor(id);

    if (i == -1) {
        printf("\n[ERRO] Leitor com ID %d nao encontrado.\n", id);
        return;
    }
    if (listaLeitores[i].livrosEmprestados > 0) {
        printf("\n[BLOQUEADO] %s ainda tem %d livro(s) emprestado(s). Registre a devolucao antes.\n",
               listaLeitores[i].nome, listaLeitores[i].livrosEmprestados);
        return;
    }

    listaLeitores[i].ativo = 0;
    salvarLeitoresCSV();
    printf("\nLeitor \"%s\" removido do fichario.\n", listaLeitores[i].nome);
}

// Submenu do modulo (chamado pelo menu principal)
// Autor: Lucas Bozek - RGM
void moduloLeitores() {
    int opcaoLeitor;

    do {
        printf("\n--- [MODULO 1: GESTAO DE LEITORES (Integrante A)] ---\n");
        printf("1. Cadastrar Novo Leitor\n");
        printf("2. Listar Leitores\n");
        printf("3. Buscar Leitor por Nome\n");
        printf("4. Editar Dados do Leitor (nome, telefone, multa)\n");
        printf("5. Remover Leitor\n");
        printf("0. Voltar ao Menu Principal\n");
        printf("Escolha uma acao: ");
        scanf("%d", &opcaoLeitor);

        switch (opcaoLeitor) {
            case 1:
                cadastrarLeitor();
                break;
            case 2:
                listarLeitores();
                break;
            case 3:
                buscarLeitorPorNome();
                break;
            case 4:
                editarLeitor();
                break;
            case 5:
                removerLeitor();
                break;
            case 0:
                printf("\nRetornando ao menu principal...\n");
                break;
            default:
                printf("\n[ERRO] Opcao invalida no Modulo de Leitores!\n");
        }
    } while (opcaoLeitor != 0);
}

#endif
